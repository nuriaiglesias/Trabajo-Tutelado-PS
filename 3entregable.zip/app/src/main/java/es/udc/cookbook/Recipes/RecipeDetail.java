package es.udc.cookbook.Recipes;public class RecipeDetail {
}
